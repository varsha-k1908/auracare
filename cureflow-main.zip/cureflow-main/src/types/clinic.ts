export type LanguageCode = 'en' | 'hi' | 'es' | 'ta' | 'te' | 'ar';

export interface LanguageConfig {
  code: LanguageCode;
  name: string;
  nativeName: string;
  bcp47: string;
  voiceLabel: string;
  confirmKeywords: string[];
  rescheduleKeywords: string[];
}

export type FollowUpStatus =
  | 'overdue'
  | 'due_in_2_days'
  | 'due_today'
  | 'calling_now'
  | 'awaiting_reply'
  | 'confirmed'
  | 'rescheduled'
  | 'staff_handoff'
  | 'completed'
  | 'missed';

export type ClinicalUrgency =
  | 'Time-Critical Hormone Window'
  | 'High Priority'
  | 'Routine Cycle Check';

export interface CallAttempt {
  id: string;
  timestamp: string;
  channel: 'voice_ivr' | 'whatsapp';
  language: LanguageCode;
  triggerType: 'T-48h Advance Auto-Call' | 'Morning Queue Auto-Dial' | 'Auto-Retry' | 'Manual Trigger';
  scriptSpoken: string;
  outcome: 'answered_pending' | 'confirmed' | 'rescheduled' | 'no_answer' | 'escalated_to_staff';
  dtmfOrTextReply?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'system_voice' | 'system_whatsapp' | 'patient' | 'automation_engine';
  timestamp: string;
  language: LanguageCode;
  text: string;
  translatedSubtext?: string;
  proposedSlots?: string[];
}

export interface PatientFollowUp {
  id: string;
  mrn: string;
  patientName: string;
  age: number;
  phone: string;
  preferredLanguage: LanguageCode;
  cycleType: string;
  procedureName: string;
  clinician: string;
  clinicalUrgency: ClinicalUrgency;
  prepInstruction: string;
  /**
   * Relative offset from today (Oct 8, 2026):
   * -3 = 3 days overdue
   * -2 = 2 days overdue
   * -1 = 1 day overdue
   *  0 = due today
   * +1 = due tomorrow
   * +2 = due in 2 days (triggers the T-48h multilingual advance call!)
   * +3..+6 = later this week
   */
  dueDateOffsetDays: number;
  scheduledDate: string; // YYYY-MM-DD
  scheduledDayLabel: string; // e.g. "Sat, Oct 10"
  scheduledTime: string; // e.g. "09:30 AM"
  previousDateLabel?: string;
  previousTime?: string;
  status: FollowUpStatus;
  attempts: number;
  maxAttempts: number;
  nextRetryIn?: string;
  assignedStaff?: string;
  escalationReason?: string;
  callLogs: CallAttempt[];
  conversation: ChatMessage[];
  lastUpdated: string;
}

export interface AutomationExecutionEvent {
  id: string;
  timestamp: string;
  patientId: string;
  patientName: string;
  language: LanguageCode;
  eventType:
    | 'T_MINUS_2_DAYS_CALL_DISPATCHED'
    | 'WHATSAPP_REMINDER_SENT'
    | 'PATIENT_CONFIRMED'
    | 'PATIENT_RESCHEDULED'
    | 'NO_RESPONSE_RETRY_SCHEDULED'
    | 'HANDOFF_TO_STAFF'
    | 'CALENDAR_AUTO_UPDATED';
  summary: string;
  detail: string;
}
