export interface CodeSnippetTab {
  id: string;
  filename: string;
  title: string;
  description: string;
  code: string;
}

export const AUTOMATION_CODE_TABS: CodeSnippetTab[] = [
  {
    id: 'scheduler',
    filename: 'automation/twoDayAdvanceCaller.ts',
    title: '1. 2-Day Advance Multilingual Voice Call Scheduler (T-48h)',
    description:
      'Runs automatically every morning at 08:00 AM. Selects all fertility follow-ups exactly 2 days away (targetDate = today + 2 days), synthesizes the script in each patient’s preferredLanguage, and places an interactive IVR voice call + WhatsApp reminder.',
    code: `import twilio from 'twilio';
import cron from 'node-cron';
import { db } from '../db/clinicStore';

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

export type PreferredLanguage = 'hi' | 'es' | 'ta' | 'te' | 'ar' | 'en';

interface VoiceLocalization {
  bcp47: string;
  twilioVoice: string;
  buildScript: (name: string, procedure: string, date: string, time: string) => string;
}

const LANGUAGE_VOICE_MAP: Record<PreferredLanguage, VoiceLocalization> = {
  hi: {
    bcp47: 'hi-IN',
    twilioVoice: 'Polly.Aditi',
    buildScript: (name, proc, date, time) =>
      \`नमस्ते \${name}, यह ऑराकेयर फर्टिलिटी क्लिनिक से आपके अपॉइंटमेंट से 2 दिन पहले की स्वचालित कॉल है। आपकी \${proc} जांच \${date} को \${time} बजे निर्धारित है। कन्फर्म करने के लिए 1 दबाएं, या रीशेड्यूल करने के लिए 2 दबाएं।\`,
  },
  es: {
    bcp47: 'es-ES',
    twilioVoice: 'Polly.Lucia-Neural',
    buildScript: (name, proc, date, time) =>
      \`Hola \${name}, esta es una llamada automática con 2 días de anticipación de AuraCare Fertility. Su cita para \${proc} es el \${date} a las \${time}. Presione 1 para confirmar o presione 2 para reprogramar.\`,
  },
  ta: {
    bcp47: 'ta-IN',
    twilioVoice: 'Google.ta-IN-Wavenet-A',
    buildScript: (name, proc, date, time) =>
      \`வணக்கம் \${name}, இது ஆராகேர் கருத்தரிப்பு மையத்திலிருந்து 2 நாட்களுக்கு முன்பு செய்யப்படும் அழைப்பு. உங்கள் \${proc} \${date} அன்று \${time} மணிக்கு உள்ளது. உறுதிப்படுத்த 1-ஐ அழுத்தவும், மாற்ற 2-ஐ அழுத்தவும்.\`,
  },
  te: {
    bcp47: 'te-IN',
    twilioVoice: 'Google.te-IN-Standard-A',
    buildScript: (name, proc, date, time) =>
      \`నమస్కారం \${name}, ఆరాకేర్ ఫెర్టిలిటీ క్లినిక్ నుండి మీ అపాయింట్‌మెంట్‌కు 2 రోజుల ముందుగా చేసే కాల్. మీ \${proc} \${date} న \${time} కి ఉంది. నిర్ధారించడానికి 1 నొక్కండి, మార్చుకోవడానికి 2 నొక్కండి.\`,
  },
  ar: {
    bcp47: 'ar-SA',
    twilioVoice: 'Polly.Zeina',
    buildScript: (name, proc, date, time) =>
      \`مرحباً \${name}، هذه مكالمة تذكير آلية قبل يومين من عيادة أوراكير للخصوبة. موعد \${proc} يوم \${date} الساعة \${time}. اضغط 1 للتأكيد أو 2 لإعادة الجدولة.\`,
  },
  en: {
    bcp47: 'en-US',
    twilioVoice: 'Polly.Joanna-Neural',
    buildScript: (name, proc, date, time) =>
      \`Hello \${name}, this is an automated 2-day advance reminder from AuraCare Fertility. Your \${proc} is scheduled on \${date} at \${time}. Press 1 to confirm, or press 2 to reschedule.\`,
  },
};

/**
 * Queries patients whose follow-up is 2 days from today and dispatches
 * an outbound Voice IVR call + WhatsApp message in their preferred language.
 */
export async function dispatchTwoDayAdvanceCalls() {
  const twoDaysFromNow = new Date();
  twoDaysFromNow.setDate(twoDaysFromNow.getDate() + 2);
  const targetIsoDate = twoDaysFromNow.toISOString().slice(0, 10);

  // 1. Fetch all unconfirmed follow-ups scheduled in 2 days (T-48h)
  const dueInTwoDaysPatients = await db.followUps.findMany({
    where: {
      scheduledDate: targetIsoDate,
      status: { in: ['due_in_2_days', 'overdue'] },
      attempts: { lt: 3 },
    },
    orderBy: { dueDateOffsetDays: 'asc' }, // Most overdue first, then T-48h
  });

  for (const patient of dueInTwoDaysPatients) {
    const lang = LANGUAGE_VOICE_MAP[patient.preferredLanguage] ?? LANGUAGE_VOICE_MAP.en;
    const script = lang.buildScript(
      patient.patientName,
      patient.procedureName,
      patient.scheduledDayLabel,
      patient.scheduledTime
    );

    // 2. Construct TwiML with <Gather> for interactive DTMF (1 = Confirm, 2 = Reschedule)
    const twiml = \`
      <Response>
        <Gather input="dtmf speech" numDigits="1" language="\${lang.bcp47}"
                action="\${process.env.APP_URL}/api/webhooks/ivr-response?patientId=\${patient.id}" method="POST">
          <Say voice="\${lang.twilioVoice}" language="\${lang.bcp47}">\${script}</Say>
        </Gather>
        <Redirect>\${process.env.APP_URL}/api/webhooks/no-answer?patientId=\${patient.id}</Redirect>
      </Response>
    \`.trim();

    // 3. Place the automated Voice Call in the patient's preferred language
    await client.calls.create({
      to: patient.phone,
      from: process.env.CLINIC_VOICE_NUMBER!,
      twiml,
      statusCallback: \`\${process.env.APP_URL}/api/webhooks/call-status?patientId=\${patient.id}\`,
    });

    // 4. Send companion WhatsApp interactive message in the same language
    await client.messages.create({
      to: \`whatsapp:\${patient.phone}\`,
      from: \`whatsapp:\${process.env.CLINIC_WHATSAPP_NUMBER!}\`,
      body: script,
    });

    await db.followUps.update({
      where: { id: patient.id },
      data: {
        status: 'awaiting_reply',
        attempts: patient.attempts + 1,
      },
    });
  }
}

// Schedule daily at 08:00 AM clinic time
cron.schedule('0 8 * * *', () => {
  dispatchTwoDayAdvanceCalls().catch(console.error);
});`,
  },
  {
    id: 'webhook',
    filename: 'automation/patientReplyWebhook.ts',
    title: '2. Patient Reply & Auto-Reschedule Webhook (Voice DTMF + WhatsApp)',
    description:
      'Processes the patient’s reply in their native language (Press 1 / "Confirm" or Press 2 / "Reschedule"). Automatically updates the clinic calendar, removes the patient from the pending call list, and sends localized confirmation.',
    code: `import express from 'express';
import { db } from '../db/clinicStore';

export const webhookRouter = express.Router();

/**
 * Handles both Voice IVR <Gather> digits and incoming WhatsApp replies.
 * Automatically updates the staff queue and clinic calendar without human intervention.
 */
webhookRouter.post('/api/webhooks/patient-response', async (req, res) => {
  const { patientId } = req.query as { patientId: string };
  const rawInput = (req.body.Digits || req.body.Body || '').trim().toLowerCase();

  const patient = await db.followUps.findUnique({ where: { id: patientId } });
  if (!patient) return res.status(404).json({ error: 'Patient not found' });

  const isConfirm =
    rawInput === '1' ||
    ['confirm', 'yes', 'हाँ', 'sí', 'ஆம்', 'అవును', 'نعم'].some((w) => rawInput.includes(w));

  const isReschedule =
    rawInput === '2' ||
    ['reschedule', 'बदलें', 'reprogramar', 'மாற்று', 'మార్చు', 'تأجيل'].some((w) =>
      rawInput.includes(w)
    );

  if (isConfirm) {
    await db.followUps.update({
      where: { id: patient.id },
      data: { status: 'confirmed', nextRetryIn: undefined },
    });
    return res.json({ status: 'confirmed', calendarUpdated: true });
  }

  if (isReschedule) {
    // Find next open ultrasound/hormone slot for the patient's clinician
    const nextSlot = await db.calendarSlots.findFirstOpen({
      clinician: patient.clinician,
      afterDate: patient.scheduledDate,
    });

    await db.followUps.update({
      where: { id: patient.id },
      data: {
        previousDateLabel: patient.scheduledDayLabel,
        previousTime: patient.scheduledTime,
        scheduledDate: nextSlot.date,
        scheduledDayLabel: nextSlot.dayLabel,
        scheduledTime: nextSlot.time,
        dueDateOffsetDays: nextSlot.offsetDays,
        status: 'rescheduled',
        nextRetryIn: undefined,
      },
    });

    return res.json({
      status: 'rescheduled',
      newSlot: nextSlot,
      staffQueueUpdated: true,
      calendarUpdated: true,
    });
  }

  return res.status(200).json({ status: 'unrecognized_input' });
});`,
  },
  {
    id: 'escalation',
    filename: 'automation/retryAndStaffHandoff.ts',
    title: '3. Auto-Retry & Staff Handoff Escalation Worker',
    description:
      'If a patient does not answer the 2-day advance call or morning reminder, the system retries up to 3 times across Voice and WhatsApp before handing the case to a clinic nurse coordinator.',
    code: `import { db } from '../db/clinicStore';
import { dispatchTwoDayAdvanceCalls } from './twoDayAdvanceCaller';

const MAX_AUTO_ATTEMPTS = 3;

export async function handleUnansweredCallOrTimeout(patientId: string) {
  const patient = await db.followUps.findUnique({ where: { id: patientId } });
  if (!patient) return;

  if (patient.attempts >= MAX_AUTO_ATTEMPTS) {
    // Hand off case to staff member after 3 unanswered automated attempts
    await db.followUps.update({
      where: { id: patient.id },
      data: {
        status: 'staff_handoff',
        assignedStaff: 'Nurse Coordinator Ritu Verma',
        escalationReason: \`No response after \${patient.attempts} automated multilingual calls/WhatsApp reminders.\`,
        nextRetryIn: undefined,
      },
    });
    return { action: 'HANDOFF_TO_STAFF', assignedTo: 'Nurse Coordinator Ritu Verma' };
  }

  // Otherwise schedule next automated retry in 2 hours
  await db.followUps.update({
    where: { id: patient.id },
    data: {
      nextRetryIn: \`Retry #\${patient.attempts + 1} scheduled in 2h\`,
    },
  });

  return { action: 'RETRY_SCHEDULED', attempt: patient.attempts + 1 };
}`,
  },
];
