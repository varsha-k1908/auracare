import { LanguageCode, LanguageConfig, PatientFollowUp } from '../types/clinic';

export const SUPPORTED_LANGUAGES: Record<LanguageCode, LanguageConfig> = {
  hi: {
    code: 'hi',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    bcp47: 'hi-IN',
    voiceLabel: 'Hindi (India) · Neural IVR',
    confirmKeywords: ['1', 'हाँ', 'पुष्टि', 'confirm', 'yes', 'ha', 'haan'],
    rescheduleKeywords: ['2', 'बदलें', 'रीशेड्यूल', 'सोमवार', 'शुक्रवार', 'reschedule', 'change', 'later'],
  },
  es: {
    code: 'es',
    name: 'Spanish',
    nativeName: 'Español',
    bcp47: 'es-ES',
    voiceLabel: 'Spanish · Neural IVR',
    confirmKeywords: ['1', 'sí', 'si', 'confirmar', 'confirmo', 'confirm'],
    rescheduleKeywords: ['2', 'reprogramar', 'cambiar', 'lunes', 'viernes', 'reschedule'],
  },
  ta: {
    code: 'ta',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    bcp47: 'ta-IN',
    voiceLabel: 'Tamil (India) · Neural IVR',
    confirmKeywords: ['1', 'ஆம்', 'உறுதி', 'confirm', 'yes'],
    rescheduleKeywords: ['2', 'மாற்று', 'வேறொரு', 'reschedule', 'change'],
  },
  te: {
    code: 'te',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    bcp47: 'te-IN',
    voiceLabel: 'Telugu (India) · Neural IVR',
    confirmKeywords: ['1', 'అవును', 'నిర్ధారించు', 'confirm', 'yes'],
    rescheduleKeywords: ['2', 'మార్చు', 'రీషెడ్యూల్', 'reschedule', 'change'],
  },
  ar: {
    code: 'ar',
    name: 'Arabic',
    nativeName: 'العربية',
    bcp47: 'ar-SA',
    voiceLabel: 'Arabic · Neural IVR',
    confirmKeywords: ['1', 'نعم', 'تأكيد', 'confirm', 'yes'],
    rescheduleKeywords: ['2', 'تغيير', 'تأجيل', 'reschedule', 'change'],
  },
  en: {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    bcp47: 'en-US',
    voiceLabel: 'English · Neural IVR',
    confirmKeywords: ['1', 'confirm', 'confirmed', 'yes', 'coming'],
    rescheduleKeywords: ['2', 'reschedule', 'move', 'change', 'monday', 'friday'],
  },
};

export function buildTwoDayVoiceScript(
  patient: Pick<PatientFollowUp, 'patientName' | 'procedureName' | 'scheduledDayLabel' | 'scheduledTime' | 'clinician' | 'prepInstruction'>,
  lang: LanguageCode
): { nativeScript: string; englishTranslation: string } {
  const firstName = patient.patientName.split(' ')[0];
  const englishTranslation = `Hello ${firstName}, this is an automated 2-day advance reminder from AuraCare Fertility Clinic. Your ${patient.procedureName} with ${patient.clinician} is scheduled in 2 days on ${patient.scheduledDayLabel} at ${patient.scheduledTime}. Prep note: ${patient.prepInstruction}. Press 1 to confirm your appointment, or press 2 to reschedule to another time slot.`;

  switch (lang) {
    case 'hi':
      return {
        nativeScript: `नमस्ते ${firstName}, यह ऑराकेयर फर्टिलिटी क्लिनिक से आपके अपॉइंटमेंट से 2 दिन पहले की स्वचालित कॉल है। आपकी ${patient.procedureName} जांच ${patient.clinician} के साथ परसों, ${patient.scheduledDayLabel} को सुबह ${patient.scheduledTime} बजे निर्धारित है। कृपया ध्यान दें: ${patient.prepInstruction}। अपॉइंटमेंट कन्फर्म करने के लिए 1 दबाएं, या समय बदलने (रीशेड्यूल करने) के लिए 2 दबाएं।`,
        englishTranslation,
      };
    case 'es':
      return {
        nativeScript: `Hola ${firstName}, esta es una llamada automática de recordatorio con 2 días de anticipación de AuraCare Fertility Clinic. Su cita para ${patient.procedureName} con ${patient.clinician} está programada en 2 días, el ${patient.scheduledDayLabel} a las ${patient.scheduledTime}. Nota de preparación: ${patient.prepInstruction}. Presione 1 para confirmar su asistencia o presione 2 para reprogramar su cita.`,
        englishTranslation,
      };
    case 'ta':
      return {
        nativeScript: `வணக்கம் ${firstName}, இது ஆராகேர் கருத்தரிப்பு மையத்திலிருந்து உங்கள் பரிசோதனைக்கு 2 நாட்களுக்கு முன்பு செய்யப்படும் தானியங்கி அழைப்பு. ${patient.clinician} உடன் உங்கள் ${patient.procedureName} இன்னும் 2 நாட்களில் (${patient.scheduledDayLabel}) ${patient.scheduledTime} மணிக்கு உள்ளது. உறுதிப்படுத்த 1-ஐ அழுத்தவும், அல்லது நேரத்தை மாற்ற 2-ஐ அழுத்தவும்.`,
        englishTranslation,
      };
    case 'te':
      return {
        nativeScript: `నమస్కారం ${firstName}, ఆరాకేర్ ఫెర్టిలిటీ క్లినిక్ నుండి మీ అపాయింట్‌మెంట్‌కు 2 రోజుల ముందుగా చేసే ఆటోమేటెడ్ కాల్ ఇది. ${patient.clinician} గారితో మీ ${patient.procedureName} మరో 2 రోజుల్లో (${patient.scheduledDayLabel}) ${patient.scheduledTime} కి నిర్ణయించబడింది. నిర్ధారించడానికి 1 నొక్కండి, లేదా సమయం మార్చుకోవడానికి 2 నొక్కండి.`,
        englishTranslation,
      };
    case 'ar':
      return {
        nativeScript: `مرحباً ${firstName}، هذه مكالمة تذكير آلية قبل يومين من عيادة أوراكير للخصوبة. موعدك لإجراء ${patient.procedureName} مع ${patient.clinician} مقرر بعد يومين في ${patient.scheduledDayLabel} الساعة ${patient.scheduledTime}. اضغط 1 لتأكيد الموعد، أو اضغط 2 لإعادة جدولة الموعد.`,
        englishTranslation,
      };
    case 'en':
    default:
      return {
        nativeScript: englishTranslation,
        englishTranslation,
      };
  }
}

export function buildWhatsAppReminder(
  patient: Pick<PatientFollowUp, 'patientName' | 'procedureName' | 'scheduledDayLabel' | 'scheduledTime' | 'clinician' | 'prepInstruction'>,
  lang: LanguageCode
): { nativeText: string; englishTranslation: string } {
  const firstName = patient.patientName.split(' ')[0];
  const englishTranslation = `Hi ${firstName}, AuraCare Fertility Reminder (2 Days Prior): Your ${patient.procedureName} with ${patient.clinician} is on ${patient.scheduledDayLabel} at ${patient.scheduledTime}. Prep: ${patient.prepInstruction}. Reply "1" to Confirm or "2" to Reschedule.`;

  switch (lang) {
    case 'hi':
      return {
        nativeText: `नमस्ते ${firstName}, ऑराकेयर फर्टिलिटी रिमाइंडर (2 दिन पूर्व): आपकी ${patient.procedureName} जांच ${patient.scheduledDayLabel} को ${patient.scheduledTime} बजे ${patient.clinician} के साथ है।\nनिर्देश: ${patient.prepInstruction}\n\n• पुष्टि करने के लिए "1" लिखें\n• समय बदलने (Reschedule) के लिए "2" लिखें`,
        englishTranslation,
      };
    case 'es':
      return {
        nativeText: `Hola ${firstName}, Recordatorio de AuraCare Fertility (2 días antes): Su ${patient.procedureName} con ${patient.clinician} es el ${patient.scheduledDayLabel} a las ${patient.scheduledTime}.\nPreparación: ${patient.prepInstruction}\n\n• Responda "1" para Confirmar\n• Responda "2" para Reprogramar`,
        englishTranslation,
      };
    case 'ta':
      return {
        nativeText: `வணக்கம் ${firstName}, ஆராகேர் நினைவூட்டல் (2 நாட்களுக்கு முன்): உங்கள் ${patient.procedureName} (${patient.clinician}) ${patient.scheduledDayLabel} அன்று ${patient.scheduledTime} மணிக்கு உள்ளது.\n\n• உறுதிப்படுத்த "1" என பதிலளிக்கவும்\n• தேதி/நேரம் மாற்ற "2" என பதிலளிக்கவும்`,
        englishTranslation,
      };
    case 'te':
      return {
        nativeText: `నమస్కారం ${firstName}, ఆరాకేర్ రిమైండర్ (2 రోజుల ముందు): ${patient.clinician} తో మీ ${patient.procedureName} ${patient.scheduledDayLabel} న ${patient.scheduledTime} కి ఉంది.\n\n• నిర్ధారించడానికి "1" అని రిప్లై ఇవ్వండి\n• రీషెడ్యూల్ చేయడానికి "2" అని రిప్లై ఇవ్వండి`,
        englishTranslation,
      };
    case 'ar':
      return {
        nativeText: `مرحباً ${firstName}، تذكير عيادة أوراكير (قبل يومين): موعد ${patient.procedureName} مع ${patient.clinician} يوم ${patient.scheduledDayLabel} الساعة ${patient.scheduledTime}.\n\n• أرسل "1" للتأكيد\n• أرسل "2" لإعادة الجدولة`,
        englishTranslation,
      };
    case 'en':
    default:
      return {
        nativeText: englishTranslation,
        englishTranslation,
      };
  }
}

export function buildPatientReplyMessage(
  intent: 'confirm' | 'reschedule',
  newDayLabel: string,
  newTime: string,
  lang: LanguageCode
): { nativeText: string; englishTranslation: string } {
  if (intent === 'confirm') {
    const englishTranslation = '1 — Confirmed. I will attend my appointment on time.';
    switch (lang) {
      case 'hi':
        return { nativeText: '1 — हाँ, मैं समय पर अपॉइंटमेंट के लिए आऊँगी।', englishTranslation };
      case 'es':
        return { nativeText: '1 — Sí, confirmo mi asistencia a la cita.', englishTranslation };
      case 'ta':
        return { nativeText: '1 — ஆம், நான் குறித்த நேரத்தில் வருவேன்.', englishTranslation };
      case 'te':
        return { nativeText: '1 — అవును, నేను సమయానికి వస్తాను.', englishTranslation };
      case 'ar':
        return { nativeText: '1 — نعم، أؤكد حضوري في الموعد المحدد.', englishTranslation };
      default:
        return { nativeText: englishTranslation, englishTranslation };
    }
  } else {
    const englishTranslation = `2 — Please reschedule my follow-up to ${newDayLabel} at ${newTime}.`;
    switch (lang) {
      case 'hi':
        return {
          nativeText: `2 — कृपया मेरा अपॉइंटमेंट बदलकर ${newDayLabel} को ${newTime} बजे कर दें।`,
          englishTranslation,
        };
      case 'es':
        return {
          nativeText: `2 — Por favor reprograme mi seguimiento para el ${newDayLabel} a las ${newTime}.`,
          englishTranslation,
        };
      case 'ta':
        return {
          nativeText: `2 — தயவுசெய்து எனது சந்திப்பை ${newDayLabel} அன்று ${newTime} மணிக்கு மாற்றவும்.`,
          englishTranslation,
        };
      case 'te':
        return {
          nativeText: `2 — దయచేసి నా అపాయింట్‌మెంట్‌ను ${newDayLabel} ${newTime} కి మార్చండి.`,
          englishTranslation,
        };
      case 'ar':
        return {
          nativeText: `2 — يرجى إعادة جدولة موعدي إلى ${newDayLabel} الساعة ${newTime}.`,
          englishTranslation,
        };
      default:
        return { nativeText: englishTranslation, englishTranslation };
    }
  }
}

export function buildSystemAutoReply(
  intent: 'confirm' | 'reschedule',
  patientName: string,
  procedureName: string,
  dayLabel: string,
  timeLabel: string,
  lang: LanguageCode
): { nativeText: string; englishTranslation: string } {
  const firstName = patientName.split(' ')[0];
  if (intent === 'confirm') {
    const englishTranslation = `Thank you ${firstName}. Your ${procedureName} on ${dayLabel} at ${timeLabel} is confirmed. Our clinic queue and calendar have been updated.`;
    switch (lang) {
      case 'hi':
        return {
          nativeText: `धन्यवाद ${firstName}। ${dayLabel} को ${timeLabel} बजे आपकी ${procedureName} जांच कन्फर्म हो गई है। क्लिनिक कैलेंडर अपडेट कर दिया गया है।`,
          englishTranslation,
        };
      case 'es':
        return {
          nativeText: `Gracias ${firstName}. Su ${procedureName} el ${dayLabel} a las ${timeLabel} está confirmado. El calendario de la clínica ha sido actualizado.`,
          englishTranslation,
        };
      case 'ta':
        return {
          nativeText: `நன்றி ${firstName}. ${dayLabel} அன்று ${timeLabel} மணிக்கு உங்கள் ${procedureName} உறுதி செய்யப்பட்டது.`,
          englishTranslation,
        };
      case 'te':
        return {
          nativeText: `ధన్యవాదాలు ${firstName}. ${dayLabel} ${timeLabel} కి మీ ${procedureName} నిర్ధారించబడింది.`,
          englishTranslation,
        };
      case 'ar':
        return {
          nativeText: `شكراً ${firstName}. تم تأكيد موعد ${procedureName} يوم ${dayLabel} الساعة ${timeLabel}.`,
          englishTranslation,
        };
      default:
        return { nativeText: englishTranslation, englishTranslation };
    }
  } else {
    const englishTranslation = `Done, ${firstName}! Your ${procedureName} has been automatically rescheduled to ${dayLabel} at ${timeLabel}. The clinician's calendar and today's call queue have updated automatically.`;
    switch (lang) {
      case 'hi':
        return {
          nativeText: `नमस्ते ${firstName}, आपकी ${procedureName} जांच स्वचालित रूप से ${dayLabel} को ${timeLabel} बजे रीशेड्यूल कर दी गई है। डॉक्टर का कैलेंडर और स्टाफ सूची अपने आप अपडेट हो गए हैं।`,
          englishTranslation,
        };
      case 'es':
        return {
          nativeText: `¡Listo, ${firstName}! Su ${procedureName} ha sido reprogramado automáticamente para el ${dayLabel} a las ${timeLabel}. La agenda médica se actualizó automáticamente.`,
          englishTranslation,
        };
      case 'ta':
        return {
          nativeText: `${firstName}, உங்கள் ${procedureName} தானாகவே ${dayLabel} அன்று ${timeLabel} மணிக்கு மாற்றப்பட்டது. மருத்துவமனை காலண்டர் புதுப்பிக்கப்பட்டது.`,
          englishTranslation,
        };
      case 'te':
        return {
          nativeText: `${firstName}, మీ ${procedureName} ఆటోమేటిక్‌గా ${dayLabel} ${timeLabel} కి మార్చబడింది. క్లినిక్ క్యాలెండర్ అప్‌డేట్ చేయబడింది.`,
          englishTranslation,
        };
      case 'ar':
        return {
          nativeText: `تم يا ${firstName}! تمت إعادة جدولة ${procedureName} تلقائياً إلى ${dayLabel} الساعة ${timeLabel}. تم تحديث تقويم العيادة تلقائياً.`,
          englishTranslation,
        };
      default:
        return { nativeText: englishTranslation, englishTranslation };
    }
  }
}

export function playWhatsAppRingChime(): void {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const playTone = (freq: number, startOffset: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.08, ctx.currentTime + startOffset);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startOffset + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + startOffset);
      osc.stop(ctx.currentTime + startOffset + duration);
    };
    playTone(587.33, 0, 0.16);
    playTone(880, 0.18, 0.25);
  } catch {
    // Ignore audio context restriction
  }
}

export function speakMultilingualCall(
  text: string,
  bcp47: string,
  onStart?: () => void,
  onEnd?: () => void
): () => void {
  if (typeof window === 'undefined') {
    onStart?.();
    onEnd?.();
    return () => {};
  }

  let cancelled = false;
  const langPrefix = bcp47.split('-')[0].toLowerCase();

  playWhatsAppRingChime();

  // First try server-streamed native neural TTS MP3 (guarantees authentic Tamil ta-IN voice on all devices)
  const ttsStreamUrl = `/api/telephony/tts-audio?lang=${encodeURIComponent(
    langPrefix
  )}&text=${encodeURIComponent(text.slice(0, 195))}`;

  const audioEl = new Audio(ttsStreamUrl);
  onStart?.();

  const fallbackToBrowserSpeech = () => {
    if (cancelled) return;
    if (!('speechSynthesis' in window)) {
      const timer = window.setTimeout(() => onEnd?.(), 3000);
      return () => window.clearTimeout(timer);
    }
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = bcp47;
      utterance.rate = 0.98;
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice =
        voices.find((v) => v.lang.toLowerCase() === bcp47.toLowerCase()) ||
        voices.find((v) => v.lang.toLowerCase().startsWith(langPrefix));
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }
      utterance.onend = () => {
        if (!cancelled) onEnd?.();
      };
      utterance.onerror = () => {
        if (!cancelled) onEnd?.();
      };
      window.speechSynthesis.speak(utterance);
    } catch {
      onEnd?.();
    }
  };

  audioEl.onended = () => {
    if (!cancelled) onEnd?.();
  };
  audioEl.onerror = () => {
    fallbackToBrowserSpeech();
  };

  audioEl.play().catch(() => {
    fallbackToBrowserSpeech();
  });

  return () => {
    cancelled = true;
    try {
      audioEl.pause();
      audioEl.src = '';
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch {
      // Ignore cleanup errors
    }
    onEnd?.();
  };
}
