import React from 'react';
import {
  Calendar,
  ArrowRight,
  CheckCircle2,
  CalendarClock,
  AlertTriangle,
  UserCheck,
} from 'lucide-react';
import { PatientFollowUp } from '../types/clinic';
import { SUPPORTED_LANGUAGES } from '../data/multilingualTemplates';

interface WeeklyCalendarAndStatsProps {
  patients: PatientFollowUp[];
  selectedPatientId: string;
  recentlyUpdatedId: string | null;
  onSelectPatient: (id: string) => void;
}

const CALENDAR_DAYS = [
  { label: 'Mon, Oct 5', short: 'Mon 5', isToday: false },
  { label: 'Tue, Oct 6', short: 'Tue 6', isToday: false },
  { label: 'Wed, Oct 7', short: 'Wed 7', isToday: false },
  { label: 'Thu, Oct 8', short: 'Thu 8 (Today)', isToday: true },
  { label: 'Fri, Oct 9', short: 'Fri 9', isToday: false },
  { label: 'Sat, Oct 10', short: 'Sat 10 (T+2d)', isToday: false },
  { label: 'Sun, Oct 11', short: 'Sun 11', isToday: false },
  { label: 'Mon, Oct 12', short: 'Mon 12', isToday: false },
];

export const WeeklyCalendarAndStats: React.FC<WeeklyCalendarAndStatsProps> = ({
  patients,
  selectedPatientId,
  recentlyUpdatedId,
  onSelectPatient,
}) => {
  const completedOrConfirmedCount = patients.filter(
    (p) => p.status === 'completed' || p.status === 'confirmed'
  ).length;
  const rescheduledCount = patients.filter((p) => p.status === 'rescheduled').length;
  const overdueOrMissedCount = patients.filter(
    (p) => p.status === 'overdue' || p.status === 'missed'
  ).length;
  const staffHandoffCount = patients.filter((p) => p.status === 'staff_handoff').length;

  return (
    <div className="space-y-8">
      {/* Weekly Summary Strip (Single-Elevation, Hairline Dividers, Tabular Numerals) */}
      <section aria-labelledby="weekly-metrics-heading" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 id="weekly-metrics-heading" className="text-base font-semibold text-slate-900">
              Weekly Follow-Up Outcome Summary (Oct 5 – Oct 12, 2026)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Live clinic totals across automated 2-day advance calls, WhatsApp confirmations, self-service reschedules, and staff escalations.
            </p>
          </div>
          <div className="text-xs text-slate-500 font-mono tabular-nums">
            Total Tracked Cycles: {patients.length}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
          {/* Metric 1: Completed & Confirmed */}
          <div className="p-5">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium text-slate-700">Completed & Confirmed</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
                {completedOrConfirmedCount}
              </span>
              <span className="text-xs text-emerald-700 font-medium">
                Zero manual staff calls required
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Confirmed via Press-1 IVR or WhatsApp reply
            </p>
          </div>

          {/* Metric 2: Rescheduled Automatically */}
          <div className="p-5">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium text-slate-700">Auto-Rescheduled This Week</span>
              <CalendarClock className="w-4 h-4 text-teal-700" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight text-teal-800 font-mono tabular-nums">
                {rescheduledCount}
              </span>
              <span className="text-xs text-teal-700 font-medium">
                Calendar self-updated
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Patient replied “2” in native language to move slot
            </p>
          </div>

          {/* Metric 3: Overdue / Pending Response */}
          <div className="p-5">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium text-slate-700">Overdue (Auto-Retrying)</span>
              <AlertTriangle className="w-4 h-4 text-amber-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight text-amber-700 font-mono tabular-nums">
                {overdueOrMissedCount}
              </span>
              <span className="text-xs text-amber-700 font-medium">
                Pinned to top of morning queue
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Automated retry active before staff escalation
            </p>
          </div>

          {/* Metric 4: Handed Off to Staff */}
          <div className="p-5">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium text-slate-700">Handed to Staff (3 No-Replies)</span>
              <UserCheck className="w-4 h-4 text-rose-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight text-rose-700 font-mono tabular-nums">
                {staffHandoffCount}
              </span>
              <span className="text-xs text-rose-700 font-medium">
                Assigned to Nurse Coordinator
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Only cases needing human phone outreach
            </p>
          </div>
        </div>
      </section>

      {/* Auto-Syncing Weekly Clinic Calendar */}
      <section aria-labelledby="clinic-calendar-heading" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-4 h-4 text-teal-700 shrink-0" />
            <div>
              <h2 id="clinic-calendar-heading" className="text-base font-semibold text-slate-900">
                Live Auto-Updating Fertility Procedure & Ultrasound Calendar
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                When a patient replies to reschedule on WhatsApp or Voice IVR, their slot automatically releases on the old day and books onto the new day.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span>Thu, Oct 8 = Today</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-teal-800">Sat, Oct 10 = T+2 Days (Auto-Call Target)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
          {CALENDAR_DAYS.map((day) => {
            const scheduledHere = patients.filter((p) => p.scheduledDayLabel === day.label);
            const movedAwayFromHere = patients.filter(
              (p) => p.previousDateLabel === day.label && p.scheduledDayLabel !== day.label
            );
            const isTPlus2 = day.label === 'Sat, Oct 10';

            return (
              <div
                key={day.label}
                className={`p-3.5 min-h-[220px] flex flex-col justify-between ${
                  day.isToday
                    ? 'bg-slate-50/90'
                    : isTPlus2
                    ? 'bg-teal-50/25'
                    : 'bg-white'
                }`}
              >
                <div>
                  {/* Day Column Header */}
                  <div className="pb-2.5 mb-2.5 border-b border-slate-200 flex items-center justify-between">
                    <span
                      className={`text-xs font-semibold ${
                        day.isToday
                          ? 'text-slate-900'
                          : isTPlus2
                          ? 'text-teal-800'
                          : 'text-slate-700'
                      }`}
                    >
                      {day.short}
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-400">
                      {scheduledHere.length}
                    </span>
                  </div>

                  {/* Released / Moved-From Slots (Shows calendar self-updating proof) */}
                  <div className="space-y-2">
                    {movedAwayFromHere.map((movedPat) => (
                      <div
                        key={`moved-${movedPat.id}`}
                        onClick={() => onSelectPatient(movedPat.id)}
                        className="p-2 rounded-lg border border-dashed border-slate-300 bg-slate-50 text-xs text-slate-400 cursor-pointer hover:border-slate-400 transition-colors"
                      >
                        <div className="font-mono tabular-nums line-through">
                          {movedPat.previousTime}
                        </div>
                        <div className="font-medium text-slate-500 line-through truncate">
                          {movedPat.patientName}
                        </div>
                        <div className="mt-1 text-[11px] text-teal-700 font-medium flex items-center gap-1">
                          <ArrowRight className="w-3 h-3 shrink-0" />
                          <span className="truncate">Moved to {movedPat.scheduledDayLabel}</span>
                        </div>
                      </div>
                    ))}

                    {/* Active Appointments on this Day */}
                    {scheduledHere.map((pat) => {
                      const isSelected = pat.id === selectedPatientId;
                      const isJustUpdated = pat.id === recentlyUpdatedId;
                      const lang = SUPPORTED_LANGUAGES[pat.preferredLanguage];

                      return (
                        <button
                          key={pat.id}
                          type="button"
                          onClick={() => onSelectPatient(pat.id)}
                          className={`w-full text-left p-2.5 rounded-lg border transition-all cursor-pointer ${
                            isJustUpdated
                              ? 'border-teal-600 bg-teal-50/90 ring-2 ring-teal-600/30'
                              : isSelected
                              ? 'border-slate-900 bg-slate-50'
                              : 'border-slate-200 bg-white hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono tabular-nums">
                            <span className="font-semibold text-slate-800">{pat.scheduledTime}</span>
                            <span>{lang.code.toUpperCase()}</span>
                          </div>
                          <div className="text-xs font-semibold text-slate-900 truncate mt-0.5">
                            {pat.patientName}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {pat.procedureName}
                          </div>
                          <div className="mt-1.5 pt-1 border-t border-slate-100 text-[11px] font-medium flex items-center justify-between">
                            {pat.status === 'rescheduled' ? (
                              <span className="text-teal-700">Auto-Rescheduled</span>
                            ) : pat.status === 'confirmed' || pat.status === 'completed' ? (
                              <span className="text-emerald-700">Confirmed</span>
                            ) : pat.status === 'overdue' ? (
                              <span className="text-amber-700">Overdue</span>
                            ) : pat.status === 'staff_handoff' ? (
                              <span className="text-rose-700">Staff Handoff</span>
                            ) : (
                              <span className="text-slate-600">T-2d Call Due</span>
                            )}
                          </div>
                        </button>
                      );
                    })}

                    {scheduledHere.length === 0 && movedAwayFromHere.length === 0 && (
                      <div className="py-6 text-center text-xs text-slate-400">
                        Open clinic slots
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
