import React, { useEffect, useState, useRef } from 'react';
import {
  Phone,
  PhoneOff,
  Lock,
  Volume2,
  CheckCircle2,
  CalendarClock,
  Smartphone,
} from 'lucide-react';
import { playWhatsAppRingChime, speakMultilingualCall, SUPPORTED_LANGUAGES } from '../data/multilingualTemplates';
import { AVAILABLE_RESCHEDULE_SLOTS } from '../data/initialPatients';
import { LanguageCode } from '../types/clinic';

export interface LiveCallSessionData {
  callId: string;
  status: 'idle' | 'ringing' | 'connected' | 'ended';
  patientId: string;
  patientName: string;
  phone: string;
  language: string;
  procedureName: string;
  scheduledDayLabel: string;
  scheduledTime: string;
  clinician: string;
  scriptText: string;
  englishTranslation: string;
  audioUrl: string;
  updatedAt: number;
}

interface LiveWhatsAppCallOverlayProps {
  session: LiveCallSessionData | null;
  isPhoneReceiverMode: boolean;
  onExitPhoneReceiverMode: () => void;
  onAnswerCall: () => void;
  onConfirmFromCall: (patientId: string) => void;
  onRescheduleFromCall: (
    patientId: string,
    slot: { date: string; dayLabel: string; time: string; offsetDays: number }
  ) => void;
  onDeclineOrNoAnswer: (patientId: string) => void;
  onTriggerTestCallOnPhone: () => void;
}

export const LiveWhatsAppCallOverlay: React.FC<LiveWhatsAppCallOverlayProps> = ({
  session,
  isPhoneReceiverMode,
  onExitPhoneReceiverMode,
  onAnswerCall,
  onConfirmFromCall,
  onRescheduleFromCall,
  onDeclineOrNoAnswer,
  onTriggerTestCallOnPhone,
}) => {
  const [callSeconds, setCallSeconds] = useState<number>(0);
  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number>(1); // Default Mon, Oct 12 · 11:15 AM
  const [isSpeakingPrompt, setIsSpeakingPrompt] = useState<boolean>(false);
  const stopAudioRef = useRef<(() => void) | null>(null);

  const isRinging = session?.status === 'ringing';
  const isConnected = session?.status === 'connected';

  // Ringing loop + mobile vibration when incoming WhatsApp call arrives
  useEffect(() => {
    if (!isRinging) return;

    playWhatsAppRingChime();
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([500, 300, 500, 300, 500]);
      } catch {
        // Ignore vibration permission error
      }
    }

    const ringInterval = window.setInterval(() => {
      playWhatsAppRingChime();
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate([400, 200, 400]);
        } catch {
          // Ignore
        }
      }
    }, 1800);

    return () => {
      window.clearInterval(ringInterval);
    };
  }, [isRinging, session?.callId]);

  // Connected timer + automatic spoken Tamil voice audio when call is answered
  useEffect(() => {
    if (!isConnected || !session) {
      setCallSeconds(0);
      if (stopAudioRef.current) {
        stopAudioRef.current();
        stopAudioRef.current = null;
      }
      return;
    }

    const langCode = (session.language as LanguageCode) || 'ta';
    const langCfg = SUPPORTED_LANGUAGES[langCode] || SUPPORTED_LANGUAGES.ta;

    stopAudioRef.current = speakMultilingualCall(
      session.scriptText,
      langCfg.bcp47,
      () => setIsSpeakingPrompt(true),
      () => setIsSpeakingPrompt(false)
    );

    const secTimer = window.setInterval(() => {
      setCallSeconds((prev) => prev + 1);
    }, 1000);

    return () => {
      window.clearInterval(secTimer);
      if (stopAudioRef.current) {
        stopAudioRef.current();
        stopAudioRef.current = null;
      }
    };
  }, [isConnected, session?.callId]);

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const rem = sec % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  if (!isPhoneReceiverMode && !isRinging && !isConnected) {
    return null;
  }

  const activePatientId = session?.patientId || 'pat-103';
  const langCode = ((session?.language as LanguageCode) || 'ta');
  const langCfg = SUPPORTED_LANGUAGES[langCode] || SUPPORTED_LANGUAGES.ta;
  const chosenSlot = AVAILABLE_RESCHEDULE_SLOTS[selectedSlotIdx] || AVAILABLE_RESCHEDULE_SLOTS[1];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-[400px] bg-[#0B141A] text-white rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col justify-between min-h-[600px]">
        {/* Top WhatsApp Encrypted Header */}
        <div className="px-5 pt-5 pb-3 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>End-to-end encrypted · WhatsApp Voice</span>
          </div>
          {isPhoneReceiverMode && (
            <button
              type="button"
              onClick={onExitPhoneReceiverMode}
              className="text-xs text-slate-400 hover:text-white px-2 py-0.5 rounded border border-slate-700"
            >
              Clinic View
            </button>
          )}
        </div>

        {/* Standby Screen when in Phone Receiver Mode waiting for a call */}
        {!isRinging && !isConnected ? (
          <div className="p-6 flex-1 flex flex-col items-center justify-center text-center space-y-5">
            <div className="w-20 h-20 rounded-full bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center">
              <Smartphone className="w-9 h-9 text-emerald-400" />
            </div>
            <div className="space-y-1.5">
              <div className="text-xs font-mono text-emerald-400">
                LIVE WHATSAPP RECEIVER READY · +91 6381552097
              </div>
              <h3 className="text-lg font-bold text-white">
                Waiting for Clinic 2-Day Advance Call...
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Keep this screen open on your phone (`+91 6381552097`). When you click{' '}
                <strong className="text-white">“Trigger WhatsApp Call (T-2d)”</strong> on your laptop
                dashboard, this phone will immediately ring with the incoming Tamil WhatsApp Voice Call!
              </p>
            </div>

            <button
              type="button"
              onClick={onTriggerTestCallOnPhone}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>Ring Incoming WhatsApp Call Now (Tamil · தமிழ்)</span>
            </button>
          </div>
        ) : (
          /* Active Ringing or Connected WhatsApp Call Screen */
          <div className="p-6 flex-1 flex flex-col justify-between">
            {/* Caller Identity */}
            <div className="text-center space-y-2 pt-2">
              <div className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
                <span>
                  {isRinging
                    ? 'Incoming WhatsApp Voice Call...'
                    : `Connected · ${formatDuration(callSeconds)}`}
                </span>
              </div>

              <h2 className="text-2xl font-bold tracking-tight text-white">
                AuraCare Fertility Clinic
              </h2>
              <div className="text-xs font-mono text-slate-300">
                To: {session?.patientName || 'Priya Nair'} ({session?.phone || '+91 6381552097'})
              </div>
              <div className="text-xs text-slate-400">
                {session?.procedureName || 'Follicular Ultrasound Scan (Day 10)'} ·{' '}
                {session?.scheduledDayLabel || 'Sat, Oct 10'} at {session?.scheduledTime || '09:30 AM'}
              </div>
            </div>

            {/* Center Avatar / Spoken Tamil Prompt Box */}
            {isRinging ? (
              <div className="my-8 flex flex-col items-center justify-center space-y-4">
                <div className="w-24 h-24 rounded-full bg-emerald-600/20 border-2 border-emerald-500 flex items-center justify-center">
                  <Phone className="w-10 h-10 text-emerald-400" />
                </div>
                <p className="text-xs text-slate-300 text-center max-w-xs">
                  Automated 2-Day Advance Follow-Up Call in{' '}
                  <strong className="text-white">
                    {langCfg.name} ({langCfg.nativeName})
                  </strong>
                </p>
              </div>
            ) : (
              /* Connected: Live Spoken Tamil Script + Interactive Response Keypad */
              <div className="my-4 space-y-3">
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-emerald-400">
                    <span className="flex items-center gap-1 font-semibold">
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>
                        {isSpeakingPrompt
                          ? `Speaking ${langCfg.name} (${langCfg.nativeName})...`
                          : `${langCfg.name} Voice Prompt`}
                      </span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (stopAudioRef.current) stopAudioRef.current();
                        if (session) {
                          stopAudioRef.current = speakMultilingualCall(
                            session.scriptText,
                            langCfg.bcp47,
                            () => setIsSpeakingPrompt(true),
                            () => setIsSpeakingPrompt(false)
                          );
                        }
                      }}
                      className="underline text-slate-300 hover:text-white cursor-pointer"
                    >
                      Replay Voice
                    </button>
                  </div>
                  <p className="text-xs text-white leading-relaxed font-medium">
                    “{session?.scriptText}”
                  </p>
                </div>

                {/* Interactive In-Call Patient Keypad (Updates Clinic Dashboard & Calendar Live) */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2.5">
                  <div className="text-[11px] font-semibold text-slate-300">
                    Tap Your Reply on This Call (Auto-Updates Clinic Calendar):
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 whitespace-nowrap">New Slot:</span>
                    <select
                      value={selectedSlotIdx}
                      onChange={(e) => setSelectedSlotIdx(Number(e.target.value))}
                      className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white"
                    >
                      {AVAILABLE_RESCHEDULE_SLOTS.map((s, idx) => (
                        <option key={`${s.date}-${s.time}`} value={idx}>
                          {s.dayLabel} · {s.time}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => onConfirmFromCall(activePatientId)}
                      className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Press 1: Confirm Appointment (உறுதி செய்)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onRescheduleFromCall(activePatientId, chosenSlot)}
                      className="w-full py-2.5 px-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <CalendarClock className="w-4 h-4" />
                      <span>
                        Press 2: Reschedule to {chosenSlot.dayLabel} ({chosenSlot.time})
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Answer / Decline Call Buttons */}
            {isRinging ? (
              <div className="pt-4 grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => onDeclineOrNoAnswer(activePatientId)}
                  className="py-3.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>Decline (Retry)</span>
                </button>

                <button
                  type="button"
                  onClick={onAnswerCall}
                  className="py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Phone className="w-4 h-4 fill-current" />
                  <span>Answer Call</span>
                </button>
              </div>
            ) : (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onDeclineOrNoAnswer(activePatientId)}
                  className="w-full py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>End Call Without Reply (Trigger Auto-Retry)</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
