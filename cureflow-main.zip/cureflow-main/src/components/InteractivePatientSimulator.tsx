import React, { useState } from 'react';
import {
  PhoneCall,
  Volume2,
  VolumeX,
  MessageSquare,
  CalendarClock,
  CheckCircle2,
  PhoneMissed,
  Send,
  Globe,
  UserCheck,
  ExternalLink,
} from 'lucide-react';
import { LanguageCode, PatientFollowUp } from '../types/clinic';
import {
  SUPPORTED_LANGUAGES,
  buildTwoDayVoiceScript,
  buildWhatsAppReminder,
} from '../data/multilingualTemplates';
import { AVAILABLE_RESCHEDULE_SLOTS } from '../data/initialPatients';

interface InteractivePatientSimulatorProps {
  patient: PatientFollowUp;
  isSpeaking: boolean;
  audioEnabled: boolean;
  liveTelephonyReady: boolean;
  lastCallStatusMessage: string | null;
  onToggleAudio: () => void;
  onTriggerTwoDayCall: (patientId: string, overridePhone?: string) => void;
  onPatientConfirm: (patientId: string) => void;
  onPatientReschedule: (
    patientId: string,
    slot: { date: string; dayLabel: string; time: string; offsetDays: number }
  ) => void;
  onSimulateNoResponse: (patientId: string) => void;
  onChangePatientLanguage: (patientId: string, lang: LanguageCode) => void;
  onUpdatePatientPhone: (patientId: string, phone: string) => void;
  onCustomPatientMessage: (patientId: string, text: string) => void;
}

export const InteractivePatientSimulator: React.FC<InteractivePatientSimulatorProps> = ({
  patient,
  isSpeaking,
  audioEnabled,
  liveTelephonyReady,
  lastCallStatusMessage,
  onToggleAudio,
  onTriggerTwoDayCall,
  onPatientConfirm,
  onPatientReschedule,
  onSimulateNoResponse,
  onChangePatientLanguage,
  onUpdatePatientPhone,
  onCustomPatientMessage,
}) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number>(1); // Default Mon, Oct 12 · 11:15 AM
  const [customInput, setCustomInput] = useState('');
  const [activeChannelTab, setActiveChannelTab] = useState<'voice' | 'whatsapp'>('voice');

  const langConfig = SUPPORTED_LANGUAGES[patient.preferredLanguage];
  const voiceScript = buildTwoDayVoiceScript(patient, patient.preferredLanguage);
  const whatsappTemplate = buildWhatsAppReminder(patient, patient.preferredLanguage);
  const chosenSlot = AVAILABLE_RESCHEDULE_SLOTS[selectedSlotIndex] || AVAILABLE_RESCHEDULE_SLOTS[0];

  const digitsOnly = patient.phone.replace(/\D/g, '');
  const e164Digits =
    digitsOnly.length === 10 ? `91${digitsOnly}` : digitsOnly.startsWith('0') ? `91${digitsOnly.slice(1)}` : digitsOnly;
  const realWhatsAppUrl = `https://wa.me/${e164Digits}?text=${encodeURIComponent(
    `📞 *AuraCare 2-Day Advance WhatsApp Call (${langConfig.nativeName})*\n\n${whatsappTemplate.nativeText}`
  )}`;
  const whatsappAppProtocolUrl = `whatsapp://send?phone=${e164Digits}&text=${encodeURIComponent(
    `📞 *AuraCare 2-Day Advance WhatsApp Call (${langConfig.nativeName})*\n\n${whatsappTemplate.nativeText}`
  )}`;

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    onCustomPatientMessage(patient.id, customInput.trim());
    setCustomInput('');
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col">
      {/* Simulator Top Header */}
      <div className="px-5 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between gap-4">
        <div className="min-w-0">
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <span>Patient Handset Simulator</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{patient.phone}</span>
          </div>
          <h3 className="text-base font-semibold tracking-tight text-white truncate mt-0.5">
            {patient.patientName} — {langConfig.nativeName} ({langConfig.name})
          </h3>
        </div>

        <button
          type="button"
          onClick={onToggleAudio}
          className="px-3 py-1.5 text-xs font-medium rounded-md border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
          title="Toggle spoken TTS audio in patient's preferred language"
        >
          {audioEnabled ? (
            <>
              <Volume2 className="w-3.5 h-3.5 text-teal-400" />
              <span>Voice Audio On</span>
            </>
          ) : (
            <>
              <VolumeX className="w-3.5 h-3.5 text-slate-400" />
              <span>Audio Muted</span>
            </>
          )}
        </button>
      </div>

      {/* Language Switcher & Channel Segmented Control */}
      <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-600">
          <Globe className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="font-medium text-slate-700 whitespace-nowrap">Preferred Language:</span>
          <select
            aria-label="Select patient preferred language"
            value={patient.preferredLanguage}
            onChange={(e) => onChangePatientLanguage(patient.id, e.target.value as LanguageCode)}
            className="bg-white border border-slate-300 rounded-md px-2 py-1 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            {Object.values(SUPPORTED_LANGUAGES).map((l) => (
              <option key={l.code} value={l.code}>
                {l.name} ({l.nativeName})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveChannelTab('voice')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeChannelTab === 'voice'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>T-2 Day Voice Call</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveChannelTab('whatsapp')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              activeChannelTab === 'whatsapp'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>WhatsApp Thread ({patient.conversation.length})</span>
          </button>
        </div>
      </div>

      {/* Main Simulator Body */}
      <div className="p-5 flex-1 flex flex-col justify-between gap-4">
        {activeChannelTab === 'voice' ? (
          <div className="space-y-4">
            {/* Call Status Header */}
            <div className="flex flex-col gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs text-slate-500">
                    <span>WhatsApp Voice Call & Neural TTS ({langConfig.nativeName})</span>
                    <span aria-hidden="true"> · </span>
                    <span>2 Days Prior (T-48h)</span>
                    <span aria-hidden="true"> · </span>
                    <span className="font-mono">{langConfig.bcp47}</span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900 mt-0.5">
                    {patient.procedureName} ({patient.scheduledDayLabel} at {patient.scheduledTime})
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onTriggerTwoDayCall(patient.id, patient.phone)}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>{isSpeaking ? 'WhatsApp Call Active...' : 'Trigger WhatsApp Call (T-2d)'}</span>
                </button>
              </div>

              {/* Editable Phone Number for Live WhatsApp Call */}
              <div className="flex flex-wrap items-center gap-2 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                <span className="text-xs font-medium text-slate-600 whitespace-nowrap">
                  WhatsApp Number:
                </span>
                <input
                  type="text"
                  value={patient.phone}
                  onChange={(e) => onUpdatePatientPhone(patient.id, e.target.value)}
                  placeholder="+91 6381552097"
                  className="flex-1 min-w-[130px] bg-white border border-slate-300 rounded-md px-2.5 py-1 text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
                <a
                  href={realWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors flex items-center gap-1 whitespace-nowrap shrink-0"
                  title="Opens WhatsApp directly to +91 6381552097 to start a real WhatsApp Call & send the Tamil reminder"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Open WhatsApp Call (+91 6381552097)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <a
                  href={whatsappAppProtocolUrl}
                  className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-md transition-colors flex items-center gap-1 whitespace-nowrap shrink-0"
                  title="Launch native WhatsApp Desktop/Mobile app for +91 6381552097"
                >
                  <span>WhatsApp App</span>
                </a>
              </div>

              {lastCallStatusMessage && (
                <div className="text-xs text-teal-800 bg-teal-50/80 border border-teal-200 rounded-lg px-3 py-2">
                  {lastCallStatusMessage}
                </div>
              )}
            </div>

            {/* Active WhatsApp Voice Call Screen & Spoken Tamil Script */}
            <div className="p-4 rounded-lg bg-slate-900 text-white border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-300 border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="font-semibold text-white">
                    WhatsApp Voice Call · AuraCare Fertility Clinic
                  </span>
                </div>
                <span className="font-mono tabular-nums text-emerald-400">
                  {isSpeaking ? 'SPEAKING TAMIL AUDIO...' : 'END-TO-END ENCRYPTED'}
                </span>
              </div>

              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>Recipient: {patient.patientName} ({patient.phone})</span>
                <span>Language: {langConfig.name} ({langConfig.nativeName})</span>
              </div>

              <p
                className="text-sm font-medium text-white leading-relaxed bg-slate-800/90 p-3 rounded-lg border border-slate-700"
                dir={patient.preferredLanguage === 'ar' ? 'rtl' : 'ltr'}
              >
                “{voiceScript.nativeScript}”
              </p>

              {patient.preferredLanguage !== 'en' && (
                <div className="text-xs text-slate-400 leading-relaxed">
                  <span className="font-semibold text-slate-300">English Translation: </span>
                  {voiceScript.englishTranslation}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* WhatsApp Conversation View */
          <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
            {patient.conversation.length === 0 ? (
              <div className="py-8 text-center border border-dashed border-slate-200 rounded-lg p-4">
                <p className="text-xs text-slate-500">
                  No messages dispatched yet for {patient.patientName}. Click{' '}
                  <strong className="text-slate-700">Place 2-Day Advance Call</strong> to send the
                  localized voice call & WhatsApp reminder.
                </p>
                <button
                  type="button"
                  onClick={() => onTriggerTwoDayCall(patient.id)}
                  className="mt-3 px-3.5 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap"
                >
                  Send T-2 Day Reminder Now
                </button>
              </div>
            ) : (
              patient.conversation.map((msg) => {
                const isPatient = msg.sender === 'patient';
                const isEngine = msg.sender === 'automation_engine';
                if (isEngine) {
                  return (
                    <div
                      key={msg.id}
                      className="p-2.5 rounded-lg bg-amber-50/80 border border-amber-200 text-xs text-amber-900"
                    >
                      <span className="font-semibold">System Escalation: </span>
                      {msg.text}
                    </div>
                  );
                }
                return (
                  <div
                    key={msg.id}
                    className={`p-3 rounded-lg border text-xs space-y-1.5 ${
                      isPatient
                        ? 'bg-teal-50/60 border-teal-200 ml-6'
                        : 'bg-slate-50 border-slate-200 mr-6'
                    }`}
                  >
                    <div className="flex items-center justify-between text-slate-500">
                      <span className="font-semibold text-slate-700">
                        {isPatient
                          ? `${patient.patientName} (Patient Reply)`
                          : msg.sender === 'system_voice'
                          ? 'AuraCare Automated Voice Call'
                          : 'AuraCare WhatsApp Bot'}
                      </span>
                      <span className="font-mono tabular-nums">{msg.timestamp}</span>
                    </div>
                    <p
                      className="text-slate-900 font-medium whitespace-pre-line leading-relaxed"
                      dir={msg.language === 'ar' ? 'rtl' : 'ltr'}
                    >
                      {msg.text}
                    </p>
                    {msg.translatedSubtext && msg.language !== 'en' && (
                      <p className="text-slate-500 pt-1 border-t border-slate-200/70">
                        Translation: {msg.translatedSubtext}
                      </p>
                    )}
                  </div>
                );
              })
            )}

            <form onSubmit={handleSendCustom} className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder={`Reply as ${patient.patientName.split(' ')[0]} (e.g., "1", "2", "Reschedule")...`}
                className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
              <button
                type="submit"
                className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                <Send className="w-3 h-3" />
                <span>Send Reply</span>
              </button>
            </form>
          </div>
        )}

        {/* Interactive Patient Response Actions (Confirm / Reschedule / No Answer) */}
        <div className="pt-4 border-t border-slate-200 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800">
              Simulate Patient Response (Updates Queue & Calendar Automatically)
            </span>
            <span className="text-slate-500 font-mono tabular-nums">
              Attempts: {patient.attempts}/{patient.maxAttempts}
            </span>
          </div>

          {/* Target Slot Selector for Rescheduling */}
          <div className="flex flex-wrap items-center gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <CalendarClock className="w-4 h-4 text-teal-700 shrink-0" />
            <span className="text-xs font-medium text-slate-700 whitespace-nowrap">
              Preferred New Slot if Rescheduling:
            </span>
            <select
              aria-label="Select preferred reschedule slot"
              value={selectedSlotIndex}
              onChange={(e) => setSelectedSlotIndex(Number(e.target.value))}
              className="flex-1 min-w-[180px] bg-white border border-slate-300 rounded-md px-2.5 py-1 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {AVAILABLE_RESCHEDULE_SLOTS.map((slot, idx) => (
                <option key={`${slot.date}-${slot.time}`} value={idx}>
                  {slot.dayLabel} · {slot.time} (Open Slot)
                </option>
              ))}
            </select>
          </div>

          {/* 3 Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => onPatientConfirm(patient.id)}
              className="px-3 py-2 text-xs font-semibold rounded-lg border border-emerald-700/30 bg-emerald-50/70 text-emerald-900 hover:bg-emerald-100 transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>Press 1: Confirm Slot</span>
            </button>

            <button
              type="button"
              onClick={() => onPatientReschedule(patient.id, chosenSlot)}
              className="px-3 py-2 text-xs font-semibold rounded-lg bg-teal-700 text-white hover:bg-teal-800 transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <CalendarClock className="w-3.5 h-3.5 shrink-0" />
              <span>Press 2: Reschedule</span>
            </button>

            <button
              type="button"
              onClick={() => onSimulateNoResponse(patient.id)}
              className="px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {patient.attempts + 1 >= patient.maxAttempts ? (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>No Reply → Staff Handoff</span>
                </>
              ) : (
                <>
                  <PhoneMissed className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>No Answer (Retry #{patient.attempts + 1})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
