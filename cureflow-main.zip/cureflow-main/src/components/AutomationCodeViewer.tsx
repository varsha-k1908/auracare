import React, { useState } from 'react';
import { Code2, Copy, Check, Play, Terminal } from 'lucide-react';
import { AUTOMATION_CODE_TABS } from '../data/automationBackendCode';
import { AutomationExecutionEvent, PatientFollowUp } from '../types/clinic';
import { SUPPORTED_LANGUAGES } from '../data/multilingualTemplates';

interface AutomationCodeViewerProps {
  patients: PatientFollowUp[];
  events: AutomationExecutionEvent[];
  onRunBatchTwoDayCalls: () => void;
}

export const AutomationCodeViewer: React.FC<AutomationCodeViewerProps> = ({
  patients,
  events,
  onRunBatchTwoDayCalls,
}) => {
  const [activeTabId, setActiveTabId] = useState<string>(AUTOMATION_CODE_TABS[0].id);
  const [copied, setCopied] = useState(false);

  const activeTab =
    AUTOMATION_CODE_TABS.find((t) => t.id === activeTabId) || AUTOMATION_CODE_TABS[0];

  const tMinusTwoCount = patients.filter((p) => p.dueDateOffsetDays === 2).length;

  const handleCopy = () => {
    navigator.clipboard.writeText(activeTab.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section
      id="automation-code"
      aria-labelledby="code-engine-heading"
      className="bg-white border border-slate-200 rounded-xl overflow-hidden"
    >
      <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <Code2 className="w-4 h-4 text-teal-700 shrink-0" />
          <div>
            <h2 id="code-engine-heading" className="text-base font-semibold text-slate-900">
              2-Day Advance Multilingual Call Engine — Production Code & Live Batch Runner
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Complete TypeScript implementation for T-48h appointment detection, preferred-language Voice IVR + WhatsApp dispatch, auto-reschedule webhook, and 3-strike staff handoff.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onRunBatchTwoDayCalls}
          className="px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Play className="w-3.5 h-3.5" />
          <span>Execute dispatchTwoDayAdvanceCalls() ({tMinusTwoCount} T-48h Patients)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        {/* Left 8 Columns: Code File Tabs & Syntax View */}
        <div className="lg:col-span-8 flex flex-col">
          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-lg overflow-x-auto">
              {AUTOMATION_CODE_TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTabId(tab.id)}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    activeTabId === tab.id
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab.filename}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Copied Code</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy File</span>
                </>
              )}
            </button>
          </div>

          <div className="px-5 py-3 bg-slate-100/70 border-b border-slate-200">
            <div className="text-xs font-semibold text-slate-800">{activeTab.title}</div>
            <p className="text-xs text-slate-600 mt-0.5">{activeTab.description}</p>
          </div>

          <div className="bg-slate-950 text-slate-100 p-5 overflow-x-auto max-h-[460px] overflow-y-auto">
            <pre className="text-xs font-mono leading-relaxed">
              <code>{activeTab.code}</code>
            </pre>
          </div>
        </div>

        {/* Right 4 Columns: Live Execution Event Log */}
        <div className="lg:col-span-4 flex flex-col bg-slate-50/50">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-800">
              <Terminal className="w-3.5 h-3.5 text-teal-700" />
              <span>Automation Webhook & Call Log</span>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {events.length} events
            </span>
          </div>

          <div className="p-4 space-y-3 overflow-y-auto max-h-[510px]">
            {events.map((evt) => {
              const lang = SUPPORTED_LANGUAGES[evt.language];
              return (
                <div
                  key={evt.id}
                  className="p-3 bg-white border border-slate-200 rounded-lg text-xs space-y-1"
                >
                  <div className="flex items-center justify-between text-slate-500 font-mono tabular-nums">
                    <span className="font-semibold text-teal-800">{evt.eventType}</span>
                    <span>{evt.timestamp}</span>
                  </div>
                  <div className="font-semibold text-slate-900">{evt.summary}</div>
                  <p className="text-slate-600 leading-relaxed">{evt.detail}</p>
                  <div className="pt-1 text-[11px] text-slate-400">
                    <span>Patient: {evt.patientName}</span>
                    <span aria-hidden="true"> · </span>
                    <span>Language: {lang.name} ({lang.nativeName})</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
